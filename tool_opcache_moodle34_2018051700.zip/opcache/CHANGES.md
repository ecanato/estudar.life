moodle-tool_opcache
===================

Changes
-------

### v3.4-r3

* 2018-05-16 - Implement Privacy API.

### v3.4-r2

* 2018-04-21 - Update OPCache GUI to latest version from upstream

### v3.4-r1

* 2017-12-12 - Check compatibility for Moodle 3.4, no functionality change.
* 2017-12-05 - Added Workaround to travis.yml for fixing Behat tests with TravisCI.

### v3.3-r1

* 2017-11-23 - Check compatibility for Moodle 3.3, no functionality change.
* 2017-11-08 - Updated travis.yml to use newer node version for fixing TravisCI error.

### Release v3.2-r3

* 2017-09-11 - Disable MySQL in Travis CI, credits to David Mudrák
* 2017-09-11 - Add security note to README

### Release v3.2-r2

* 2017-08-14 - Add nagios check as CLI script

### Release v3.2-r1

* 2017-08-08 - Initial version
