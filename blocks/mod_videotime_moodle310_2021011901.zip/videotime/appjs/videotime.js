(function(t) {
    t.CoreUtilsProvider.videoTimeUtils.pageInit(t);
})(this);